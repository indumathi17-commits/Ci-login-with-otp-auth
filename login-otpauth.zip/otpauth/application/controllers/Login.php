<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
        $this->load->model('Login_model');
    }

	public function index()
	{
		$this->load->view('login');
	}

    public function send_otp()
    {
        $email= $this->input->post('email');
        $check_user= $this->Login_model->check_user($email);
        if($check_user){
            $random_num = mt_rand(100000, 999999);
            $insert_otp= $this->Login_model->insertOtp($email,$random_num);
            $sess_data=array(
                "email" => $email
            );
            $this->session->set_userdata($sess_data);
            if($insert_otp){
                //Write otp sending script
                echo 1;
             }else{
                 echo 2;
             }
        }else{
            echo 0;
        }
    }

    public function otp_form()
    {
        $this->load->view('otp_form');
    }

    public function check_otp()
    {
        $email= $this->session->userdata('email');
        $otpValue= $this->input->post('otp');
        $check_otp= $this->Login_model->check_otp($email, $otpValue);
        if($check_otp){
            echo 1;
        }else{
            echo 0;
        }
    }

    public function dashboard()
    {
        $email= $this->session->userdata('email');
        $remove_otp = $this->Login_model->removeOtp($email);
        if($remove_otp){
            $data["user_emailid"] = $email;
            $this->load->view('dashboard',$data);
        }else{
            echo "Something Went Wrong!";
        }
        
    }

    public function logout()
    {
        $this->session->sess_destroy();
        $this->index();
    }

}
