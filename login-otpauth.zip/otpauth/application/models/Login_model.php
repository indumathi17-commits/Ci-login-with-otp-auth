<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login_model extends CI_Model {

    public function __construct()
    {
        parent::__construct();
        $this->load->database();
    }

    public function check_user($email)
    {
       $query= $this->db->select("phone_no")->from("users")->where("email",$email)->get();
       if($query->num_rows() > 0){
           return $query->row('phone_no');
       }else{
          return false; 
       }
       
    }
    public function insertOtp($email,$random_num)
    {
       $data= array(
         "verify_otp" => $random_num
       );

       $query= $this->db->where("email",$email)->update('users',$data);
       if($query){
           return true;
       }else{
          return false; 
       }
       
    }

    public function check_otp($email, $otpValue)
    {
        $query= $this->db->select("*")->from("users")->where("email",$email)->where("verify_otp",$otpValue)->get();
        if($query->num_rows() > 0){
            return true;
        }else{
           return false; 
        }
    }

    public function removeOtp($email)
    {
       $data= array(
         "verify_otp" => ""
       );

       $query= $this->db->where("email",$email)->update('users',$data);
       if($query){
           return true;
       }else{
          return false; 
       }
       
    }

    
}
